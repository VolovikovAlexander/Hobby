﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Contracts.Payroll
{
    public class OrderPayrollContract
    {
        public decimal FOT { get; set; }
	    public int EmpCount { get; set; }
    }
}
